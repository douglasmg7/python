from setuptools import setup

setup(
    name='anotation',   # Distribution name.
    version='1.1',
    description='Just an example to install a package.',
    author='Douglas Gomes',
    author_email='dmg@some.com',
    url='dmg.com',
    py_module=['anotation']     # Files to include in the package.
 )

